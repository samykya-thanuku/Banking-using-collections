package com.cg.banking.utility;

public class BankingUtility {
	public static int CUSTOMER_ID_COUNTER=111; 
	//public static int ACCOUNT_ID_COUNTER=100;
	public static int ACCOUNT_NUM_COUNTER=2000;
	public static int TRANSACTION_ID_COUNTER=111;
public static final String ACCOUNT_STATUS_ACTIVE="active";
public static final String ACCOUNT_STATUS_INACTIVE="inactive";
}
