
/*package com.cg.banking.main;

import java.util.Scanner;

import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {

	public static void main(String[] args) {
		//throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException {
		BankingServicesImpl bankingservices=new BankingServicesImpl();
		int customerId,pinNumber;
		long accountNo;
		float amount;
		int num=0;

		//try {			
			Scanner scanner=new Scanner(System.in);
			while(num!=11) {
				System.out.println("Enter "+"\n"+
						"1 : Add Customer"+"\n"+
						"2 : Open Account"+"\n"+
						"3 : Generate New Pin"+"\n"+
						"4 : Change Account Pin"+"\n"+
						"5 : Deposit amount"+"\n"+
						"6 : Withdraw amount"+"\n"+
						"7 : Fund Transfer"+"\n"+
						"8 : Show Balance"+"\n"+
						"9 : View All Customer Details"+"\n"+
						"10 : View Account Detaills"+"\n"+
						"11 : View AllTransaction Details");
				num=scanner.nextInt();
				switch (num) {
				case 1:	
					System.out.println("Enter customer details");
					System.out.println("Enter First Name");
					String firstName=scanner.next();
					System.out.println("Enter Last Name");
					String lastName=scanner.next();
					System.out.println("Enter emailId");
					String emailId=scanner.next();
					System.out.println("Enter panCard");
					String panCard=scanner.next();
					System.out.println("Enter LocalAddressCity");
					String localAddressCity=scanner.next();
					System.out.println("Enter LocalAddressState");
					String localAddressState=scanner.next();
					System.out.println("Enter LocalAddresspinCode");
					int localAddressPinCode=scanner.nextInt();
					System.out.println("Enter HomeAddresscity");
					String homeAddressCity=scanner.next();
					System.out.println("Enter HomeAddressState");
					String homeAddressState=scanner.next();
					System.out.println("Enter  homeAddressPinCode");
					int  homeAddressPinCode=scanner.nextInt();
					customerId= bankingservices.acceptCustomerDetails(firstName, lastName, emailId, panCard, localAddressCity, localAddressState, localAddressPinCode, homeAddressCity, homeAddressState, homeAddressPinCode);
					System.out.println("CustomerId is" + customerId);
					break;
				case 2: 
					System.out.println("Opening Account");
					System.out.println("Enter Custoemer Id");
					customerId=scanner.nextInt();
					System.out.println("Enter Account Type");
					String accountType=scanner.next();
					System.out.println("Enter Initial Balance");
					float initBalance=scanner.nextFloat();
					accountNo=bankingservices.openAccount(customerId, accountType, initBalance);
					System.out.println("Account No is" + " "+accountNo);
					break;
				case 3:
					System.out.println("Enter CustomerId");
					customerId=scanner.nextInt();
					System.out.println("Enter Account number");
					accountNo=scanner.nextLong(); 
					pinNumber=bankingservices.generateNewPin(customerId, accountNo);
					System.out.println("pin Number is"+pinNumber);
					break;
				case 4:
					System.out.println("Enter CustomerId");
					customerId=scanner.nextInt();
					System.out.println("Enter Account number");
					accountNo=scanner.nextLong(); 
					System.out.println("Enter the old Pin Number");
					pinNumber=scanner.nextInt();
					System.out.println("Enter the New Pin Number");
					int newPinNumber=scanner.nextInt();
					System.out.println(bankingservices.changeAccountPin(customerId, accountNo, pinNumber, newPinNumber));
					break;
				case 5: 
					System.out.println("Enter CustomerId");
					customerId=scanner.nextInt();
					System.out.println("Enter Account number");
					accountNo=scanner.nextLong(); 
					System.out.println("Enter amount to  deposit");
					amount=scanner.nextFloat();
					System.out.println(bankingservices.depositAmount(customerId, accountNo, amount));
					break;
				case 6:
					System.out.println("Enter CustomerId");
					customerId=scanner.nextInt();
					System.out.println("Enter Account number");
					accountNo=scanner.nextLong(); 
					System.out.println("Enter amount to  Withdraw");
					amount=scanner.nextFloat();
					System.out.println("Enter the Pin Number");
					pinNumber=scanner.nextInt();
					bankingservices.withdrawAmount(customerId, accountNo, amount, pinNumber);
					break;
				case 7:
					System.out.println("Enter CustomerIdTo");
					customerId=scanner.nextInt();
					System.out.println("Enter Account numberTo");
					accountNo=scanner.nextLong(); 
					System.out.println("Enter CustomerIdFrom");
					int customerId2=scanner.nextInt();
					System.out.println("Enter Account numberFrom");
					long accountNo2=scanner.nextLong(); 
					System.out.println("Enter the amount to Transfer");
					amount=scanner.nextFloat();
					System.out.println("Enter the Pin Number");
					pinNumber=scanner.nextInt();
					bankingservices.fundTransfer(customerId, accountNo, customerId2, accountNo2, amount, pinNumber);
					System.out.println("Remaining Balance" + " " + bankingservices.getAccountDetails(customerId2, accountNo2).getAccountBalance());
					break;
				case 8:
					System.out.println("Enter CustomerId");
					customerId=scanner.nextInt();
					System.out.println("Enter Account number");
					accountNo=scanner.nextLong();
					System.out.println("Enter Pin Number");
					pinNumber=scanner.nextInt();
					if(bankingservices.getAccountDetails(customerId, accountNo).getPinNumber()==pinNumber) {
						System.out.println("Balance"+" "+bankingservices.getAccountDetails(customerId, accountNo).getAccountBalance());
					}
					else 
						System.out.println("Entered Wrong Pin");
					break;
				case 9:
					System.out.println("Viewing All Customer Details");
					for (Customer customer : bankingservices.getAllCustomerDetails()) {
						System.out.println(customer);
					}					
					break;
				case 10: 
					System.out.println("View account details");
					System.out.println("Enter CustomerId");
					customerId=scanner.nextInt();
					System.out.println("Enter Account number");
					accountNo=scanner.nextLong(); 
					System.out.println(bankingservices.getAccountDetails(customerId, accountNo));					
					break;
				case 11:
					System.out.println("View All Transaction details");
					System.out.println("Enter CustomerId");
					customerId=scanner.nextInt();
					System.out.println("Enter Account number");
					accountNo=scanner.nextLong();
					for ( Transaction transaction : bankingservices.getAccountAllTransaction(customerId, accountNo)) {
						System.out.println(transaction);
					}
					break;
				default: 
					System.out.println("Enter the valid key ");
					break;
				}


			}


		}
		/*catch (BankingServicesDownException e) {
			e.printStackTrace();

		}
		catch (InvalidAmountException e) {
			e.printStackTrace();


		}
		catch (CustomerNotFoundException e) {
			e.printStackTrace();

		}
		catch (InvalidAccountTypeException e) {
			e.printStackTrace();

		}
		catch (InsufficientAmountException e) {
			e.printStackTrace();

		}
		catch (AccountNotFoundException e) {
			e.printStackTrace();

		}
		catch (InvalidPinNumberException e) {
			e.printStackTrace();

		}
		catch (AccountBlockedException e) {
			e.printStackTrace();

		}
	}
*/
