package com.cg.banking.beans;

public class Transaction {
	private int transactionId,  amount;
	private String transactionType, timeStamp, transactionLocation, modeOfTransaction, transactionStatus;
	public Transaction(){}
	public Transaction(float amount, String modeOfTransaction){
		this.amount=(int) amount;
		this.modeOfTransaction=modeOfTransaction;
	}
	public Transaction(int transactionId, String timeStamp, int amount, String transactionType, String transactionLocation,
			String modeOfTransaction, String transactionStatus) {
		super();
		this.transactionId = transactionId;
		this.timeStamp = timeStamp;
		this.amount = amount;
		this.transactionType = transactionType;
		this.transactionLocation = transactionLocation;
		this.modeOfTransaction = modeOfTransaction;
		this.transactionStatus = transactionStatus;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getTransactionLocation() {
		return transactionLocation;
	}
	public void setTransactionLocation(String transactionLocation) {
		this.transactionLocation = transactionLocation;
	}
	public String getModeOfTransaction() {
		return modeOfTransaction;
	}
	public void setModeOfTransation(String modeOfTransaction) {
		this.modeOfTransaction = modeOfTransaction;
	}
	public String getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + amount;
		result = prime * result + ((modeOfTransaction == null) ? 0 : modeOfTransaction.hashCode());
		result = prime * result + ((timeStamp == null) ? 0 : timeStamp.hashCode());
		result = prime * result + transactionId;
		result = prime * result + ((transactionLocation == null) ? 0 : transactionLocation.hashCode());
		result = prime * result + ((transactionStatus == null) ? 0 : transactionStatus.hashCode());
		result = prime * result + ((transactionType == null) ? 0 : transactionType.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Transaction other = (Transaction) obj;
		if (amount != other.amount)
			return false;
		if (modeOfTransaction == null) {
			if (other.modeOfTransaction != null)
				return false;
		} else if (!modeOfTransaction.equals(other.modeOfTransaction))
			return false;
		if (timeStamp == null) {
			if (other.timeStamp != null)
				return false;
		} else if (!timeStamp.equals(other.timeStamp))
			return false;
		if (transactionId != other.transactionId)
			return false;
		if (transactionLocation == null) {
			if (other.transactionLocation != null)
				return false;
		} else if (!transactionLocation.equals(other.transactionLocation))
			return false;
		if (transactionStatus == null) {
			if (other.transactionStatus != null)
				return false;
		} else if (!transactionStatus.equals(other.transactionStatus))
			return false;
		if (transactionType == null) {
			if (other.transactionType != null)
				return false;
		} else if (!transactionType.equals(other.transactionType))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", amount=" + amount + ", transactionType="
				+ transactionType + ", timeStamp=" + timeStamp + ", transactionLocation=" + transactionLocation
				+ ", modeOfTransaction=" + modeOfTransaction + ", transactionStatus=" + transactionStatus + "]";
	}
	
	

}
